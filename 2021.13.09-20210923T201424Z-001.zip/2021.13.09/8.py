import turtle
import math

turtle.shape('turtle')
turtle.speed(0)
k=1
for i in range(0,36000,1):

    turtle.goto(k*i*math.sin(math.pi*i/2)+k*i*math.cos(math.pi*i/2),k*i*math.sin(math.pi*i/2)-k*i*math.cos(math.pi*i/2))
    turtle.left(90)
tirtle.done(0)
