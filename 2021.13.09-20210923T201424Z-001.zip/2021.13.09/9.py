import turtle
import math

def f(n,r):
    turtle.penup()
    turtle.goto(r/2,0)
    turtle.pendown()
    for i in range(1,n+1,1):
        turtle.goto(r/2*math.cos(math.pi*2*i/n),r/2*math.sin(math.pi*2*i/n))



turtle.shape('turtle')
turtle.speed(0)
k=40
Rad=0
for i in range(0,36000,1):
    Rad=i*k
    f(i,Rad*(1.1**i))
tirtle.done(0)
