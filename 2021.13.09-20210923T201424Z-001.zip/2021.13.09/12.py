import turtle
import math
r=100

def f(r):
    for i in range(18):

        turtle.left(10)
        turtle.forward(r*2*math.pi/90)



turtle.shape('turtle')
turtle.speed(0)
k=40
n=100
for i in range(1,n):
    f(100)
    f(10)
turtle.done()
