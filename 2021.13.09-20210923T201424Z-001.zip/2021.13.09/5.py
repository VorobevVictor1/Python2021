import turtle

turtle.shape('turtle')
#turtle.speed(0)
for i in range(1,11):
    turtle.forward(i*50)
    turtle.left(90)
    turtle.forward(50*i)
    turtle.left(90)
    turtle.forward(50*i)
    turtle.left(90)
    turtle.forward(50*i)
    turtle.left(90)
    turtle.penup()
    turtle.goto(-25*i,-25*i)
    turtle.pendown()
tirtle.done(0)
