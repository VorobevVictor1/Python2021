import turtle
import math
r=100

def f(x,y):
    turtle.penup()

    turtle.goto(x+r,y)
    turtle.pendown()
    for i in range(90):
        turtle.left(4)
        turtle.forward(r*2*math.pi/90)



turtle.shape('turtle')
turtle.speed(0)
k=40
n=6
for i in range(0,n,1):
    f(r*math.cos(math.pi*2*i/n),r*math.sin(math.pi*2*i/n))
turtle.done()
