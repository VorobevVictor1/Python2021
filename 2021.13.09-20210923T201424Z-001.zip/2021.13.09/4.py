import turtle

turtle.shape('turtle')
turtle.speed(0)
for i in range(360):
    turtle.left(1)
    turtle.forward(1)
