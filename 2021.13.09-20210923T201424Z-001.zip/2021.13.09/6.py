import turtle

turtle.shape('turtle')
#turtle.speed(0)
n=100
for i in range(1,n+1):
    turtle.forward(200)
    turtle.left(360/n)
    turtle.stamp()
    turtle.goto(0,0)

tirtle.done(0)
