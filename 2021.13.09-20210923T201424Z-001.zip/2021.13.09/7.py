import turtle
import math

turtle.shape('turtle')
turtle.speed(0)
k=0.1
for i in range(0,36000,1):

    turtle.goto(k*i*math.cos(i/10),k*i*math.sin(i/10))
    turtle.left(180/3.14*0.1)
tirtle.done(0)
