import turtle
import math
r=100

def f(r,x,y,ang):
    turtle.penup()
    turtle.goto(x,y)
    turtle.pendown()
    turtle.right(90)
    for i in range(ang):

        turtle.left(10)
        turtle.forward(r*2*math.pi/18)
    turtle.right(ang*10)



turtle.shape('turtle')
turtle.speed(0)

turtle.begin_fill()
f(100,0,0,36)
turtle.end_fill()

turtle.color("red")

turtle.begin_fill()
f(10,100,100,36)
turtle.end_fill()

turtle.begin_fill()
f(10,-100,100,36)
turtle.end_fill()

f(60,0,-50,18)

turtle.done()
