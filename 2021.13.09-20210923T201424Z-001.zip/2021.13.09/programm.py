
def f(x):
  up=1/(np.sin(x)+1.)
  up=np.exp(up)
  down=5./4.+x**(-15)
  up=up/down
  down=np.log(1+x*x)
  up=up/down
  return up

print(f(1),f(10),f(1000))

x = np.arange(-0.99, -0.98, 0.00001)
plt.figure(figsize=(15, 10))
plt.plot(x, f(x))
plt.xlabel(r'$x$')
plt.ylabel(r'$f(x)$')
plt.title(r'$f(x)$')
plt.grid(True)
plt.show()
